let produtosData = [];

// Carrega o arquivo JSON do estoque
async function carregarEstoque() {
  try {
    const response = await fetch('estoque.json');
    produtosData = await response.json();
    renderizarCards();
  } catch (error) {
    console.error('Erro ao carregar o estoque:', error);
    alert('Não foi possível carregar o arquivo estoque.json.');
  }
}

// Renderiza os cards de produtos na tela
function renderizarCards() {
  const container = document.getElementById('gridProdutos');
  container.innerHTML = '';

  produtosData.forEach(produto => {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <img src="${produto.foto}" alt="${produto.nome}">
      <div class="card-body">
        <span class="badge-unidade">${produto.unidade}</span>
        <h3 class="card-title">${produto.nome}</h3>
        <div class="card-info"><strong>Preço de Compra:</strong> R$ ${produto.precoCompra.toFixed(2)}</div>
        <div class="card-info"><strong>Preço de Venda:</strong> R$ ${produto.precoVenda.toFixed(2)}</div>
        <div class="card-info"><strong>Estoque Atual:</strong> ${produto.quantidadeEstoque}</div>
        
        <div class="card-control">
          <label for="mov-${produto.id}">Entrada / Saída (negativo):</label>
          <input type="number" id="mov-${produto.id}" value="0" step="1" placeholder="Ex: 5 ou -3">
        </div>
      </div>
    `;
    container.appendChild(card);
  });
}

// Controles do Modal (inspirado no Exemplo6.1)
function abrirModal() {
  document.getElementById('modalOverlay').style.display = 'flex';
}

function fecharModal() {
  document.getElementById('modalOverlay').style.display = 'none';
  document.getElementById('formProduto').reset();
}

// Exercício 6.1.a — Adiciona o novo produto ao estoque e re-renderiza
function incluirProduto(event) {
  event.preventDefault();

  const nome = document.getElementById('nome').value.trim();
  const foto = document.getElementById('foto').value.trim();
  const precoCompra = parseFloat(document.getElementById('precoCompra').value);
  const precoVenda = parseFloat(document.getElementById('precoVenda').value);
  const quantidadeEstoque = parseInt(document.getElementById('quantidadeEstoque').value, 10);
  const unidade = document.getElementById('unidade').value.trim();

  const novoProduto = {
    id: Date.now(),
    nome,
    foto,
    precoCompra,
    precoVenda,
    quantidadeEstoque,
    unidade
  };

  produtosData.push(novoProduto);
  renderizarCards();
  fecharModal();
}

// Exercício 6.1.b — Lê o valor de Entrada/Saída de cada produto e atualiza a quantidade em estoque
function atualizarEstoque() {
  produtosData.forEach(produto => {
    const input = document.getElementById(`mov-${produto.id}`);
    const movimentacao = parseInt(input.value, 10) || 0;

    produto.quantidadeEstoque += movimentacao;
  });

  renderizarCards();
}

// Exercício 6.1.b — Gera e baixa um arquivo JSON com o estoque atualizado (Data URI Scheme, igual ao Exemplo6.1)
function salvarEstoque() {
  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(produtosData, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute("href", dataStr);
  downloadAnchor.setAttribute("download", "estoque_atualizado.json");
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}
